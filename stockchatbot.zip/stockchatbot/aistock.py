from rasa_nlu.model import Interpreter
from iexfinance import Stock
import json

interpreter = Interpreter.load("./models/current/nlu")


def send_message(policy, state, message):
    print("USER : {}".format(message))
    new_state, response = respond(policy, state, message)
    print("BOT : {}".format(response))
    return new_state

def respond(policy, state, message):
    (new_state, response) = policy[(state, interpret(message))]
    return new_state, response

def interpret(message):
    data = interpreter.parse(message)
    if data.get('intent').get('name') == 'greet':                     
        return 'greet' 
    if data.get('intent').get('name') == 'stock_search':
        if data.get('entities').get('entity') == 'price':
            price = Stock(data.get('entities').get('value')).get_price()
            return 'stock_price'
        if data.get('entities').get('entity') == 'volume':
            volume = Stock(data.get('entities').get('value')).get_volume()
            return 'volume'
        if data.get('entities').get('entity') == '':
            return 'none'



# Define the states
INIT = 0
CHOOSE = 1
PENDING = 2
THANK_YOU = 3

# Define the policy rules dictionary
policy_rules = {
    (INIT, 'greet'): (INIT, "Hello. I'm a stock inquiry bot. You can ask the stock of a specific company"),
    (INIT, 'none'): (CHOOSE, "OK, you can ask me for stock price or trading volume"),
    (CHOOSE, 'stock_price'): (THANK_YOU, str(price)),
    (CHOOSE, 'volume'): (THANK_YOU, str(volume))
}

# Define send_messages()
def send_messages(messages):
    state = INIT
    for msg in messages:
        state = send_message(policy,state, msg)

# Send the messages

send_messages([
    "what can you do for me?",
    "Ok, let's see AAPL",
    "stock price",
    "Thanks"
])

